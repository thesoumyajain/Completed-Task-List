<?php
/*
Plugin Name: Display Unique Customer ID
Description: Display the Unique Customer ID whilst the user logged in
Author: Soumya Jain
Author URI: mailto:thesoumyajain@gmail.com
Domain Path: /languages
*/

// disabling direct file access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// load text domain
function plugin_load_textdomain() {

	load_plugin_textdomain( 'customer_id', false, plugin_dir_path( __FILE__ ) . 'languages/' );

}
add_action( 'plugins_loaded', 'plugin_load_textdomain' );

/*
 * This function will display the user Id for the logged in user
 */
function display_logged_in_user_ID() {
    global $current_user;
    get_currentuserinfo();
    
    //Display the user ID only if user is logged in 
    if ( is_user_logged_in() ) {
        echo 'User ID: ' . $current_user->ID . "\n";
    }
} 

//Shortcode to display the ID for logged in user
add_shortcode('display_user_Id', 'display_logged_in_user_ID');